var express = require('express');
var router = express.Router();
var availabilityManager = require('../services/availabilityManager.js');

router.post('/', (req, res) => {

    var name = req.body.name;
    var date = req.body.date;

    var isCandidateAvailable = availabilityManager.isCandidateAvailable(name, date);
    if (isCandidateAvailable["available"] == true) {

        var isRecruitersAvailable = availabilityManager.isRecruitersAvailable(date);
        if (isRecruitersAvailable) {

            var isRecruitersQualify = availabilityManager.isRecruitersQualify(isCandidateAvailable["data"], date);
            if (isRecruitersQualify) {
                res.json({ message : "Ok" });
            } else {
                res.json({ message : "No recruiters qualify" });
            }
            
        } else {
            res.json({ message : "No recruiters available" });
        }

    } else {
        res.json({ message : isCandidateAvailable["data"] });
    }

});

module.exports = router;