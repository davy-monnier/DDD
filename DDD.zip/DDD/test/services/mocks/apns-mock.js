//mock for apple notification
var iosMessages = [];

module.exports = {
    Connection: function() {
        this.pushNotification = function(notification, device) {
            iosMessages = iosMessages || [];
            iosMessages.push({ message: notification.payload, deviceId: device.getToken() })
        };

        this.on = function() { };
    },
    Device: function(deviceToken) {
        this.getToken = function() { return deviceToken; }
    },
    Notification: function() { },
    iosMessages: function(){
        return iosMessages;
    },
    reset : function(){
        iosMessages = [];
    }
}