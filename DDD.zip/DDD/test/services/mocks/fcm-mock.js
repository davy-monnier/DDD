//mock for google notification
var androidMessages = [];

function FCM(serverKey) {
    //Rien de spécial
}

FCM.prototype.send = function(message, callback) {
    androidMessages = androidMessages || [];
    androidMessages.push({ message: message, deviceId: message.to });
};

module.exports = FCM;
module.exports.androidMessages = androidMessages;