var fs = require('fs'),
    mongoose = require('mongoose'),
    populate,
    clean;
    
    
/**
 * Permet de supprimer l'ensemble des collections d'une base.
 */
clean = function () {
    return new Promise(function (resolve, reject) {
        for (var collection in mongoose.connection.collections) {
            mongoose.connection.collections[collection].remove(function () { });
        }
        resolve();
    });
}

/**
 * Permet d'insérer des données (utilisateurs, etc), Retourne une promise
 */
populate = function (jsonPath) {

    return new Promise(function (resolve, reject) {
        clean().then(function () {
            var data = JSON.parse(fs.readFileSync(jsonPath)),
                collectionIndex = 0,
                documentIndex = 0,
                total = 0,
                cpt = 0,
                documents = [],
                document = {},
                name;

            for (collectionIndex = 0; collectionIndex < data.length; collectionIndex += 1) {
                documents = data[collectionIndex].documents;
                total += documents.length;
            }

            for (collectionIndex = 0; collectionIndex < data.length; collectionIndex += 1) {
                documents = data[collectionIndex].documents;
                name = data[collectionIndex].collection;
                for (documentIndex = 0; documentIndex < documents.length; documentIndex += 1) {
                    document = documents[documentIndex];
                    
                    if (document.password) {
                        document.password = bcrypt.hashSync(document.password, bcrypt.genSaltSync(10));
                    }
                    
                    if (document._id) {
                       document._id = mongoose.Types.ObjectId(document._id);
                    }

                    if (document.event) {
                        document.event = mongoose.Types.ObjectId(document.event);
                    }

                    if (document.user) {
                        document.user = mongoose.Types.ObjectId(document.user);
                    } 
                    
                    if (document.owner) {
                       document.owner = mongoose.Types.ObjectId(document.owner);
                    } 
                    
                    if (document.rescuers) {
                        document.rescuers.forEach(function(data) {
                            if (data.rescuer){
                                data.rescuer = mongoose.Types.ObjectId(data.rescuer);
                            }
                        })
                    } 
                    if (document.users) {
                        document.users.forEach(function(data) {
                            if (data._id){
                                data._id = mongoose.Types.ObjectId(data.user);
                            }
                        })
                    }

                    mongoose.connection.collections[name].insert(documents[documentIndex], {}, function() {
                        cpt++;
                        if (cpt == total) {
                            resolve();
                        }
                    });
                }
            }
            
        })
        .catch(function (err) {
            console.log(err);
            reject(err);
        });
    });
}

exports.populate = populate;