var User = require('../model/user.js');

exports.isCandidateAvailable = (name, date) => {

    User.findOne({ name: name }, (err, users) => {

        var result;
        if (err) {
            result = {
                available: false,
                data: err
            }
        } else {
            if (users && users[0].isCandidate) {
                var isCandidateAvailable = false;
                user.availabilities.forEach(availabily => {
                    if (availabily.available && availabily.date == date) {
                        isCandidateAvailable = true;
                    }
                });
                result = {
                    available: isCandidateAvailable,
                    data: isCandidateAvailable ? user.techno : "Candidate isn't available"
                }
            } else {
                result = {
                    available: false,
                    data: "No candidates found"
                }
            }
        }
        return result;

    });

}

exports.isRecruitersAvailable = (date) => {

    User.find().exec.then(users => {

        var isRecuitersAvailable = false;
        users.forEach(user => {
            if (!user.isCandidate) {
                user.availabilities.forEach(availabily => {
                    if (availabily.available && availabily.date == date) {
                        isRecuitersAvailable = true;
                    }
                });
            }
        });
        return isRecuitersAvailable;

    });

}

exports.isRecruitersQualify = (techno, date) => {


    User.findOne({ techno: techno }, (err, users) => {

        var isRecuitersAvailable = false;
        if (users) {
            users.forEach(user => {
                if (!user.isCandidate) {
                    user.availabilities.forEach(availabily => {
                        if (availabily.available && availabily.date == date) {
                            isRecuitersAvailable = true;
                        }
                    });
                }
            });
        }
        return isRecuitersAvailable;

    });

}